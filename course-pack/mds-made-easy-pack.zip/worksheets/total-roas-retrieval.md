# Worksheet — Total ROAS retrieval

Fill from **your** store. Do not invent.

## Period

- Start: __________  
- End: __________  
- Sales basis: ☐ Total Sales  ☐ Net Sales  

## Numbers

| | Amount |
| --- | --- |
| Sales | $ __________ |
| Ad spend (all paid) | $ __________ |
| Total ROAS (sales ÷ spend) | __________ × |

## Platform contrast (optional)

| Platform | That platform’s ROAS (their claim) |
| --- | --- |
| Meta | __________ |
| Google | __________ |

**One sentence:** Why these platform numbers are a **different claim** than Total ROAS:


## Misalignment check

Sales window matches spend window? ☐ Yes  ☐ No → **stop and fix**

## Recall (no peeking at module)

Formula: _________________________________
