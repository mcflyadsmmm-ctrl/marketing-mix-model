# Worksheet — CSV / export QA checklist

**Period:** ____ → ____ · **Currency:** ____ · **TZ story:** ____

## Sales export

| Check | Pass? |
| --- | --- |
| Basis labeled (Total / Net) | ☐ |
| Dates match spend window | ☐ |
| Refunds / returns understood | ☐ |
| Filename includes window | ☐ |

## Spend CSV

| Check | Pass? |
| --- | --- |
| `date,channel,amount` (or consistent wide) | ☐ |
| No `$` / thousands commas | ☐ |
| No duplicate channel-day | ☐ |
| No sales / ROAS columns treated as till truth | ☐ |
| Totals ≈ ad UIs (± fees) | ☐ |
| Channels named consistently | ☐ |
| Filename includes window | ☐ |

## Gate

All boxes checked? ☐ Yes → compute Total ROAS  
Any fail? ☐ → **stop** — list fixes:


## Sample row (correct)

```csv
date,channel,amount
YYYY-MM-DD,meta,____
YYYY-MM-DD,google,____
```
