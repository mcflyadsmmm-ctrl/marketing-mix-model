# Sample Monday memo (fictional store)

**Not your numbers.** Use this once to see the shape, then fill the blank [monday-memo.md](monday-memo.md) with your store.

---

**Period:** 2026-07-20 → 2026-07-26  
**Sales basis:** ☑ Total  ☐ Net  
**Contribution margin:** 38 %  
**Break-even Total ROAS:** 2.63 ×  

| | $ |
| --- | --- |
| Sales | 84,200 |
| Ad spend | 31,500 |
| **Total ROAS** | 2.67 × |

**vs BE:** ☑ above  ☐ below  ☐ flat  

**One move:** ☐ Cut  ☐ Protect  ☑ Shift  

**Detail (one line):**  
Shift $2,000/week from low-volume prospecting tests into always-on; hold brand; no MTA claim — portfolio clears BE on average.

**Flags (missing data / TZ / refunds):**  
Store TZ used for both sales and spend. Refunds already in Total Sales. No new-customer split this week → skip aMER.

**Owner / date:** Alex (ops) / 2026-07-27  

---

Religion check: Total ROAS = sales ÷ spend for the same period. This memo does **not** claim which click “caused” the orders.
