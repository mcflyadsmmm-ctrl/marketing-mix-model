# Worksheet — Monday memo (print weekly)

Copy this sheet each week. Spaced practice > re-reading.

---

**Period:** __________ → __________  
**Sales basis:** ☐ Total  ☐ Net  
**Contribution margin:** ______ %  
**Break-even Total ROAS:** ______ ×  

| | $ |
| --- | --- |
| Sales | |
| Ad spend | |
| **Total ROAS** | ______ × |

**vs BE:** ☐ above  ☐ below  ☐ flat  

**One move:** ☐ Cut  ☐ Protect  ☐ Shift  

**Detail (one line):**


**Flags (missing data / TZ / refunds):**


**Owner / date:** __________  

---

Share with finance as plain text if needed. No pixels. No “true ROAS.”
