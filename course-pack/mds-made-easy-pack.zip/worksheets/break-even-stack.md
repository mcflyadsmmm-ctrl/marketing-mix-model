# Worksheet — Break-even margin stack

## Margin source

☐ Finance given %   ☐ Built from stack below   ☐ Estimate (label risk)

### Optional stack

| Cost | % of sales |
| --- | --- |
| COGS | ____ % |
| Payment fees | ____ % |
| Variable shipping | ____ % |
| Packaging / other variable | ____ % |
| **Sum** | ____ % |
| **Contribution margin** = 100 − sum | ____ % |

## Break-even

```text
BE Total ROAS ≈ 1 ÷ (margin as decimal) = __________ ×
```

## Compare

| | Value |
| --- | --- |
| Period | ____ → ____ |
| Total ROAS | ____ × |
| BE | ____ × |
| Result | ☐ above  ☐ below  ☐ flat |

## One sentence (no causality)


## Practice math

| Margin | BE |
| --- | --- |
| 25% | ____ × |
| 40% | ____ × |
| 50% | ____ × |
