# MDS Made Easy — paid course pack

**Purpose:** What you receive after Stripe $79.  
**Public teaser:** https://mcflyads.com/mds-made-easy/  
**Religion:** Total ROAS = sales ÷ spend (same period). Refuse pixels, MTA, “true ROAS,” TW clones.

## Start here

**First 20 minutes:** open [START_HERE.md](START_HERE.md) before bingeing modules.

## How you got this

1. You paid **$79 once** on Stripe Payment Link.  
2. Stripe showed a **hosted confirmation** with this private pack link (secret gist).  
3. Stripe emailed your receipt with the same link.  

Mcfly does **not** use Gumroad, Kajabi, or a monthly LMS. There is no Cloudflare unlock — keep a local copy of these files.

## What’s in the pack

| # | File | Topic |
| --- | --- | --- |
| 0 | [START_HERE.md](START_HERE.md) | Day-1 path (20 minutes) |
| 1 | [modules/01-total-roas.md](modules/01-total-roas.md) | Total ROAS, period-aligned |
| 2 | [modules/02-break-even.md](modules/02-break-even.md) | Break-even from margin |
| 3 | [modules/03-import-export.md](modules/03-import-export.md) | Import & export finance trusts |
| 4 | [modules/04-monday-ritual.md](modules/04-monday-ritual.md) | Monday budget ritual |
| 5 | [modules/05-ai-prompts.md](modules/05-ai-prompts.md) | Full AI prompt kit |
| 6 | [modules/06-glossary.md](modules/06-glossary.md) | Glossary + refuse list |
| 7 | [modules/07-suites-and-custom.md](modules/07-suites-and-custom.md) | Suites, Custom, stop DIY |

**Worksheets (print / fill):**

- [worksheets/total-roas-retrieval.md](worksheets/total-roas-retrieval.md)
- [worksheets/break-even-stack.md](worksheets/break-even-stack.md)
- [worksheets/csv-qa-checklist.md](worksheets/csv-qa-checklist.md)
- [worksheets/monday-memo.md](worksheets/monday-memo.md) (blank)
- [worksheets/monday-memo-sample.md](worksheets/monday-memo-sample.md) (fictional filled example)
- [worksheets/sample-spend-dirty.csv](worksheets/sample-spend-dirty.csv) (QA repair drill)

Optional: zip the folder locally. Founder may mirror a zip on private Drive — **gist remains primary delivery**. When pack changes, founder must **refresh the secret gist**.

## How to use (adult-learning shape)

1. Follow [START_HERE.md](START_HERE.md).  
2. Skim free teasers + labs on the site if helpful.  
3. Work one pack module + its worksheet the same day (retrieval > re-reading).  
4. Run the Monday memo for four weeks — spaced practice.  
5. Only then brief AI with pasted numbers.

## Next product steps

- Install Free Shopify cash desk: https://mcflyads.com/support  
- Custom / desk inquire: https://mcflyads.com/custom-analytics#inquire  

Support: mcflyadsmmm@gmail.com · subject `MDS Made Easy access`
