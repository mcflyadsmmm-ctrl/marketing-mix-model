# 03 — Import & export finance trusts

**Learning objective:** Produce a period-aligned sales + spend pair finance trusts — before any model or AI.

**Rule:** Sales window = spend window. Currency consistent. No double-counted channels. Then compute.

---

## Sales export (Shopify)

1. Choose basis: **Total Sales** or **Net Sales** — write it on the file.  
2. Export / sum for exact `START → END`.  
3. Know whether refunds are already netted on your Net basis.  
4. Filename: `sales_YYYY-MM-DD_YYYY-MM-DD_total.csv` (or `_net`).

---

## Spend CSV spine

Long form (preferred for QA):

```csv
date,channel,amount
2026-07-01,meta,1200.50
2026-07-01,google,890.00
2026-07-01,other,150.00
```

Wide daily form also works if consistent:

```csv
date,meta,google,other
2026-07-01,1200.50,890.00,150.00
```

### Hygiene

| Rule | Why |
| --- | --- |
| Store currency | No FX surprise mid-file |
| No `$` or thousands commas | Parsers break |
| One channel-day row | Avoid double count |
| No sales columns in spend file | Till sales stay in Shopify export |
| Name the window in the filename | `spend_2026-07-01_2026-07-31.csv` |

---

## QA checklist (must pass)

Print [worksheets/csv-qa-checklist.md](../worksheets/csv-qa-checklist.md).

1. Sales start/end = spend start/end.  
2. No duplicate channel-day.  
3. Totals ≈ ad UIs (± fee timing).  
4. One timezone story (store vs ad account).  
5. Basis labeled (Total vs Net).  
6. Channels named consistently (meta / google / other).  

**Fail any → stop.** Do not compute Total ROAS. Do not paste into AI.

---

## Dirty CSV drill (repair)

Open [worksheets/sample-spend-dirty.csv](../worksheets/sample-spend-dirty.csv). Issues on purpose: `$` + thousands comma, duplicate meta same day, inconsistent channel casing.

Broken paste (same content):

```csv
date,channel,amount
2026-07-01,meta,$1,200.50
2026-07-01,meta,400
2026-07-02,google,890
2026-07-03,Meta,210.00
```

Fixed example:

```csv
date,channel,amount
2026-07-01,meta,1600.50
2026-07-02,google,890.00
2026-07-03,meta,210.00
```

(Or two intentional meta rows that sum — never silent duplicates.)

---

## Refuse

- Connector zoo as the product (pipes optional; the number is the product)  
- Platform “ROAS” columns treated as Total ROAS  
- Shipping attributed sales into the spend file  

---

## Self-check

1. Name three QA failures that block Total ROAS.  
2. What belongs in a spend CSV vs a sales export?  
3. Why does timezone matter?

---

## Cross-sell

- Sheets spend guide (site): https://mcflyads.com/assets/mcfly-sheets-spend-guide.html  
- Free desk: https://mcflyads.com/support  
- Next: [04-monday-ritual.md](04-monday-ritual.md)
