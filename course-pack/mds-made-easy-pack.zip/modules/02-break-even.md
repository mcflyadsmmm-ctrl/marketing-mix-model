# 02 — Break-even from contribution margin

**Learning objective:** Set a stable break-even Total ROAS and say whether the period clears the floor — without claiming channel causality.

**Claim:** Break-even Total ROAS ≈ **1 ÷ contribution margin** (decimal).

```text
Break-even Total ROAS ≈ 1 ÷ contribution margin
```

---

## Worked examples

| Margin | BE Total ROAS | Reading if live = 3.0× |
| --- | --- | --- |
| 25% (0.25) | 4.00× | Below floor |
| 35% (0.35) | ≈ 2.86× | Above floor |
| 40% (0.40) | 2.50× | Above floor |
| 50% (0.50) | 2.00× | Above floor |

**Sentence template:**  
*Period ____ → ____: Total ROAS ____× vs BE ____× — above / below / flat the floor on average.*

---

## What goes in “margin”

Use contribution after costs that scale with an order — whatever finance treats as till-level:

- COGS / product cost  
- Variable shipping you eat  
- Payment fees  
- Variable packaging  

**Consistency > perfection.** Do not redefine mid-quarter without noting it on the memo.

Optional stack:

```text
contribution % ≈ 1 − COGS% − fees% − variable shipping% − packaging%
```

If you only have a single % from finance, use that and label the source.

---

## How to read the comparison

| Result | Action language |
| --- | --- |
| Total ROAS ≥ BE | Portfolio clears the floor on average. Protect or selective shift. |
| Total ROAS &lt; BE | Something must change: spend, mix, offer, or margin. Prefer cut / shift with floors. |
| Equal / within noise | Hold; do not celebrate causality. |

**Not causal:** Clearing the floor does **not** prove a channel “worked.”

---

## Do this

1. Write contribution margin % and source (finance / estimate).  
2. Compute BE = 1 / margin.  
3. Compute period Total ROAS (module 01).  
4. One sentence: above / below / flat.  
5. Carry BE into Monday ritual (module 04).

---

## Refuse

- Pretending BE proves channel causality  
- Mixing contribution margin with accounting net profit without saying so  
- Changing margin definition weekly to “make ROAS look good”  

---

## Self-check

1. Margin 40% → BE = ?  
2. Live Total ROAS 2.2× at 40% margin — above or below?  
3. Does “above BE” mean Meta caused the orders?

Fill [worksheets/break-even-stack.md](../worksheets/break-even-stack.md).

---

## Cross-sell

- Free desk: https://mcflyads.com/support  
- Custom inquire: https://mcflyads.com/custom-analytics#inquire  
- Next: [03-import-export.md](03-import-export.md)
