# 01 — Total ROAS, period-aligned

**Learning objective:** Compute and defend Total ROAS for a named period without mixing platform ROAS or misaligned dates.

**Claim:** Total ROAS = **Shopify sales ÷ ad spend** on the **same dates**.

```text
Total ROAS = Sales (period) ÷ Ad spend (same period)
```

Average portfolio efficiency — **not** which click caused the order, **not** marginal channel return.

---

## Worked example

| Input | Value |
| --- | --- |
| Period | 2026-07-01 → 2026-07-31 |
| Sales basis | Total Sales |
| Shopify Total Sales | $120,000 |
| Meta + Google + Other spend | $40,000 |

**Total ROAS = 120000 ÷ 40000 = 3.00×**

Memo line: *July Total Sales ÷ paid spend = 3.00× (period-aligned).*

### Misaligned trap (refuse)

| Sales window | Spend window | Verdict |
| --- | --- | --- |
| Jul 1–31 | Jun 1–30 | **Stop.** Different claim. |
| Jul 1–31 | Jul 1–31 | OK to compute. |
| MTD (partial) | Last 30 days | **Stop.** Align both. |

---

## Do this

1. Write the period on paper: `START → END`.  
2. Pull Shopify **Total Sales** (or Net — label it) for that window only.  
3. Sum paid spend for the **same** window (CSV/paste is fine).  
4. Divide. Write **one** number with a ×.  
5. Say aloud: “This is till Total ROAS, not Ads Manager ROAS.”

---

## Platform ROAS vs Total ROAS

| | Platform ROAS | Total ROAS |
| --- | --- | --- |
| Numerator | Platform-credited conversions | Shopify sales (chosen basis) |
| Denominator | That platform’s spend | All paid spend in window |
| Job | Channel ops | Finance / Monday affordability |

Keep both if useful. Never blend them into one “truth.”

---

## aMER (optional, honest)

If you have opaque new-customer sales for the same period:

```text
aMER ≈ new-customer sales ÷ total ad spend
```

Level-1 only — no CRM merge required. Missing new-customer sales → **do not invent**.

---

## Refuse

- Blending platform-attributed ROAS into the till number  
- “True ROAS,” view-through, path credit  
- Different date windows for sales vs spend  
- Claiming channel profitability from blended Total ROAS alone  

---

## Self-check (retrieval)

Close this file. Answer without looking:

1. Formula for Total ROAS?  
2. What do you do if sales end-date ≠ spend end-date?  
3. Is 3.0× “proof” Meta worked?

Then open [worksheets/total-roas-retrieval.md](../worksheets/total-roas-retrieval.md) and fill blanks with **your** store numbers.

---

## Cross-sell (link out)

- Free desk: https://mcflyads.com/support  
- Custom inquire: https://mcflyads.com/custom-analytics#inquire  
- Next module: [02-break-even.md](02-break-even.md)
