# 07 — Suites, Custom, and when to stop DIY

**Learning objective:** Choose DIY Free desk, keep suite for politics, or buy Custom — without ripping out tools you still need.

## Coexist map

| Surface | Job |
| --- | --- |
| **Shopify App (Free / Pro)** | Weekly till close inside Admin — Total ROAS, BE, CSV spend |
| **Attribution suites** | Path / CYA decks for stakeholders who still want them |
| **This course ($79)** | Teach the ritual + pack so humans can run the desk |
| **Custom Data Solutions** | Fixed-fee when multi-system / governance exceeds DIY |

Suites own path narratives. Mcfly owns **sales ÷ spend**, break-even, and the Monday move.

---

## Keep the suite when…

- Stakeholders still want path narratives for politics.  
- You already pay and it is not the Monday bottleneck.  

## Lean on Free / Pro when…

- You need period-aligned Total ROAS in minutes.  
- CSV spend is enough (or Pro named channels).  
- You want a flat fee later — not a GMV tax.  

## Buy Custom when…

- Non-Shopify or multi-system books.  
- You need written metric contracts and a weekly decision desk.  
- DIY CSV + AI prompts are not enough governance.  

Stop DIY when the **cost of wrong dates/exports** exceeds a scoped SOW.

---

## Decision tree (one page)

```text
Need path deck for politics? → Keep suite (optional).
Need till Total ROAS this week? → Free desk + this pack.
Multi-system / SOW governance? → Custom inquire.
Still debating “true ROAS”? → Refuse; rewrite to sales ÷ spend vs BE.
```

---

## Course complete checklist

- [ ] Align windows before any ratio  
- [ ] Compute Total ROAS with labeled basis  
- [ ] Set BE from contribution margin  
- [ ] Pass CSV QA  
- [ ] Write one cut / protect / shift sentence  
- [ ] Brief AI without invented numbers  
- [ ] Know DIY vs Custom trigger  

---

## Cross-sell (link out only)

- Install Free: https://mcflyads.com/support  
- Custom inquire: https://mcflyads.com/custom-analytics#inquire  
- Suites comparison (site): https://mcflyads.com/vs-attribution-suites  
- Hub: https://mcflyads.com/mds-made-easy/
