# 04 — Monday budget ritual

**Learning objective:** End every Monday (or any close day) with **one** defendable budget sentence — not a model debate.

**Sequence (same order every week):**

1. **Margin** — confirm contribution % / BE still valid  
2. **Spend** — CSV / paste for the period  
3. **Sales** — Shopify same dates + labeled basis  
4. **Compare** — Total ROAS vs break-even  
5. **One call** — cut / protect / shift · write it down  

---

## Inputs table (fill each week)

| Field | This week |
| --- | --- |
| Period | ____ → ____ |
| Sales basis | Total / Net |
| Contribution margin % | ____ |
| Break-even Total ROAS | ____× |
| Sales $ | ____ |
| Spend $ | ____ |
| Total ROAS | ____× |
| vs BE | above / below / flat |
| One move | Cut / Protect / Shift |
| Move detail (1 line) | ________________ |

Printable blank: [worksheets/monday-memo.md](../worksheets/monday-memo.md)

---

## Allocation language (keep it boring)

| Move | Meaning |
| --- | --- |
| **Cut** | Reduce discretionary spend while below floor (or clearly wasteful volume). Keep spend floors if needed. |
| **Protect** | Hold always-on / brand / contractual spend; do not starve for theater. |
| **Shift** | Move dollars toward clearer till contribution **without** inventing MTA or channel ROAS. |

**Sentence templates:**

- *Below BE at ____× vs ____× — cut ____% from discretionary ____; protect always-on ____.*  
- *Above BE — protect core mix; shift $____ from ____ to ____ as a step-test, not a causal claim.*  
- *Flat — hold spend; fix data QA before any cut.*

---

## Export / share habit

End with a five-line memo (Share Overview or email paste):

```text
Period: …
Basis: Total | Net
Sales / Spend / Total ROAS / BE
One move: Cut | Protect | Shift — …
Flags: missing inputs / TZ / refunds — …
```

No pixel theater in the ritual. Suites may keep path decks elsewhere.

---

## Spaced practice

Run the memo **four consecutive weeks**. Same template. Retrieval beats re-reading modules 01–03.

---

## Refuse

- Ending the meeting with “we need better attribution” as the only action  
- Inventing channel ROAS to justify a cut  
- Skipping QA because “we’re late to the call”  

---

## Self-check

1. Recite the five steps in order.  
2. Write one Cut and one Protect sentence with fake numbers.  
3. What do you do if sales and spend windows disagree mid-meeting?

---

## Cross-sell

- Free desk: https://mcflyads.com/support  
- Custom inquire: https://mcflyads.com/custom-analytics#inquire  
- Next: [05-ai-prompts.md](05-ai-prompts.md)
