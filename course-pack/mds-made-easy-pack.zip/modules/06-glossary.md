# 06 — Glossary + refuse list

**Learning objective:** Brief a junior on till terms and refuse attribution theater without apologizing.

## Terms (teach these)

| Term | Meaning here |
| --- | --- |
| Total ROAS | Sales ÷ spend, same period. Average portfolio efficiency. |
| Break-even Total ROAS | ≈ 1 ÷ contribution margin. Floor for the period. |
| Contribution margin | % left after variable till costs (COGS, fees, variable shipping…). |
| Period alignment | Sales and spend share start/end (and one TZ story). |
| Total Sales vs Net | Pick a basis; never mix mid-week. |
| Ad spend | Cash to paid channels in the window (CSV OK). |
| CSV spend import | Merchant-supplied daily channel amounts — not path data. |
| aMER | Optional new-customer sales ÷ spend (Level-1). Still not MTA. |
| Allocation | Cut / protect / shift — one Monday move. |
| Platform ROAS | That platform’s credited return — different claim. |
| Garbage-in / garbage-out | Bad windows → confident nonsense from AI or Sheets. |
| Custom desk | Fixed-fee Mcfly engagement for multi-system desks. |

## Refuse (do not teach as Mcfly truth)

| Term | Stance |
| --- | --- |
| Path credit / MTA | Suites may; till course refuses as product curriculum. |
| “True ROAS” | Marketing phrase for causal theater. |
| Pixels / CAPI as the desk | Not required for sales ÷ spend. |
| TW / Northbeam feature clones | Coexist; do not clone. |
| SyncWith connector zoo | Pipes optional; number is the product. |
| Robyn / Meridian as the course | Out of scope. |

## Refuse quiz (answers)

1. Leadership wants “true ROAS by click path.” → **Rewrite to Total ROAS vs BE.**  
2. Sales MTD; spend last-30. → **Stop; align windows.**  
3. AI invents channel ROAS you never pasted. → **Reject; require pasted tables.**

## Self-check

Without looking: define Total ROAS, BE, period alignment, and one refuse term.

## Cross-sell

- Free desk: https://mcflyads.com/support  
- Custom inquire: https://mcflyads.com/custom-analytics#inquire  
- Next: [07-suites-and-custom.md](07-suites-and-custom.md)
