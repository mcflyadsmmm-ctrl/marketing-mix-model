# 05 — AI prompts with correct inputs

**Learning objective:** Brief AI only with period-aligned inputs; reject invented numbers and attribution theater.

**Law:** You supply sales, spend, margin, and windows. The model computes and drafts. Missing number → say **unknown** — never fabricate.

---

## Before you paste

1. Date window at the top.  
2. Totals or a small table — not mismatched screenshots.  
3. Sales basis: Total or Net.  
4. Add: *Do not invent numbers. If something is missing, ask.*

### Refuse these asks

Rewrite “true ROAS / MTA / pixel paths” into till questions: period Total ROAS, break-even, CSV QA, one allocation sentence.

---

## Prompt kit — copy and fill

### 1 · Period-align check

```text
You are a marketing cash-desk analyst. I will give sales and spend date ranges.
Confirm whether they are period-aligned. If not, say exactly how to fix them.
Do not compute ROAS until dates match.
Sales window: START → END
Spend window: START → END
```

### 2 · Total ROAS from pasted totals

```text
Compute Total ROAS = Sales ÷ Ad spend for one period.
Use only the numbers I paste. Do not invent or pull external data.
If spend is 0 or missing, say you cannot compute.
Period: START → END
Sales basis: Total Sales | Net Sales
Sales: $____
Ad spend: $____
Return: Total ROAS as a multiple (e.g. 3.10×) and a one-sentence reading.
```

### 3 · Break-even from margin stack

```text
Contribution margin = ____% (or build from: COGS% __ , fees% __ , shipping% __ ).
Break-even Total ROAS ≈ 1 ÷ margin.
Compare to my Total ROAS of ____× for period START → END.
Say whether I am above or below the floor. Do not claim channel causality.
```

### 4 · Above/below Monday brief

```text
Write a 5-sentence Monday brief for finance.
Inputs: period, sales, spend, Total ROAS, break-even Total ROAS, one proposed move (cut/protect/shift).
Tone: calm operator. No pixels, MTA, or “true ROAS.”
Inputs:
…
```

### 5 · Allocation draft (rules-based)

```text
Using only this channel spend table and Total ROAS vs break-even, draft cut / protect / shift bullets.
No MTA. No inventing channel ROAS. If a channel has no till evidence, say “protect pending data.”
Table:
channel, spend
…
Total ROAS: __× | Break-even: __×
```

### 6 · CSV spend QA

```text
Audit this spend CSV for: duplicate channel-days, non-numeric amounts, missing dates in range, mixed currencies, sales columns mixed into spend.
Return a checklist of issues. Do not invent spend totals.
Paste CSV:
…
```

### 7 · Export column map

```text
Map my export headers to: date, channel, amount (spend) and/or date, sales.
Say which columns to keep, rename, or drop. Refuse to treat platform “ROAS” columns as Total ROAS.
Headers:
…
```

### 8 · aMER honesty pass

```text
Compute aMER ≈ new-customer sales ÷ spend if I provide both.
State Level-1 limits: opaque ids / counts only — no CRM. If new-customer sales missing, stop.
Period: … | New-customer sales: … | Spend: …
```

### 9 · Finance one-pager

```text
Produce a one-page CFO memo: period, sales basis, sales, spend, Total ROAS, break-even, variance vs last period if provided, one budget call.
No attribution theater. Flag any missing input.
```

### 10 · Refuse-the-ask rewrite

```text
I was asked: “________” (pixel / MTA / true ROAS / path).
Rewrite into a till-desk question I can answer with sales ÷ spend and break-even.
Then answer the rewritten question only if I paste numbers; otherwise list required inputs.
```

---

## Drill (retrieval)

1. Ask an AI for “true ROAS by click path” using prompt 10 — keep only the rewrite.  
2. Paste misaligned dates into prompt 1 — confirm it refuses to compute.  
3. Paste only sales (no spend) into prompt 2 — confirm it stops.

---

## Cross-sell

- Free desk: https://mcflyads.com/support  
- Custom inquire: https://mcflyads.com/custom-analytics#inquire  
- Next: [06-glossary.md](06-glossary.md)
