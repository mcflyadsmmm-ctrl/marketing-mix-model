# START HERE — first 20 minutes

You paid $79. Do this path once. Then run the Monday memo weekly.

## Minute 0–2 — save local copies

1. Keep this gist open (or download the zip if you have it).  
2. Copy the folder somewhere you will find on Monday.  
3. Skim [README.md](README.md) once — delivery was Stripe confirmation → this pack.

## Minute 2–12 — worksheets in order

Do **not** binge all seven modules first. Retrieval beats re-reading.

| # | Open | Do |
| --- | --- | --- |
| 1 | [worksheets/total-roas-retrieval.md](worksheets/total-roas-retrieval.md) | Fill with **your** last complete week (or MTD). If dates disagree, stop. |
| 2 | [worksheets/break-even-stack.md](worksheets/break-even-stack.md) | Write margin → BE → above/below. |
| 3 | [worksheets/csv-qa-checklist.md](worksheets/csv-qa-checklist.md) | Pass/fail your spend export. Fail = fix before AI. |
| 4 | [worksheets/monday-memo.md](worksheets/monday-memo.md) | One cut / protect / shift sentence. |

Need a worked shape? See [worksheets/monday-memo-sample.md](worksheets/monday-memo-sample.md) (fictional store — not your numbers).

Stuck on a term? [modules/01-total-roas.md](modules/01-total-roas.md) → [02](modules/02-break-even.md) → [03](modules/03-import-export.md) → [04](modules/04-monday-ritual.md).

## Minute 12–18 — prompts only after numbers exist

Open [modules/05-ai-prompts.md](modules/05-ai-prompts.md). Paste **only** numbers from your worksheets. If something is missing, the model must say so.

## Minute 18–20 — product next step (link out)

Pick one:

- **DIY desk this week:** Install Free Shopify cash desk → https://mcflyads.com/support  
- **Multi-system / SOW:** Custom inquire → https://mcflyads.com/custom-analytics#inquire  

Do not wait for a “course portal.” There isn’t one — that is the point.

## After today

Run [worksheets/monday-memo.md](worksheets/monday-memo.md) for **four weeks**. Same template. Spaced practice.

Support: mcflyadsmmm@gmail.com · subject `MDS Made Easy access`
